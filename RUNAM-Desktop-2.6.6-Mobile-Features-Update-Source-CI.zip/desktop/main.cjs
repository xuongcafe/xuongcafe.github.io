const { app, BrowserWindow, Menu, shell, session, dialog, ipcMain } = require("electron");
const express = require("express");
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { pathToFileURL } = require("node:url");
const Database = require("better-sqlite3");
const QRCode = require("qrcode");

const PRODUCT_NAME = "Phiếu giao hàng - Xưởng Cafe";
const API_PORT = 43128;
const LOCAL_PORT = 43127;
const LAN_PORT = 43129;
const API_ORIGIN = `http://127.0.0.1:${API_PORT}`;
const LOCAL_ORIGIN = `http://127.0.0.1:${LOCAL_PORT}`;
const publicDir = path.resolve(__dirname, "../public");
let localServer;
let lanServer;
let lanTransferCode;
let lanInboxDir;
let backendModule;
let mainWindow;
let dataDir;
let databasePath;
let quitting = false;
let printDialogActive = false;

function backendEntryPath() {
  if (app.isPackaged) return path.join(process.resourcesPath, "app.asar.unpacked", "server", "server.mjs");
  return path.join(app.getAppPath(), "server", "server.mjs");
}

async function startEmbeddedApi() {
  dataDir = path.join(app.getPath("userData"), "data");
  databasePath = path.join(dataDir, "pgh.sqlite");
  fs.mkdirSync(dataDir, { recursive: true });
  process.env.HOST = "127.0.0.1";
  process.env.PORT = String(API_PORT);
  process.env.DATA_DIR = dataDir;
  process.env.COOKIE_SECURE = "false";
  process.env.PGH_LOCAL_NO_AUTH = "1";
  backendModule = await import(pathToFileURL(backendEntryPath()).href);
  const healthStatus = await new Promise((resolve, reject) => {
    const request = http.get(`${API_ORIGIN}/api/health`, response => {
      response.resume();
      response.on("end", () => resolve(response.statusCode || 0));
    });
    request.setTimeout(30000, () => request.destroy(new Error("Health check quá thời gian.")));
    request.on("error", reject);
  });
  if (healthStatus < 200 || healthStatus >= 300) throw new Error(`Backend SQLite không sẵn sàng (HTTP ${healthStatus}).`);
}

function proxyApi(req, res) {
  const target = new URL(req.originalUrl, API_ORIGIN);
  const headers = { ...req.headers, host: target.host };
  for (const name of ["connection", "proxy-connection", "keep-alive", "transfer-encoding", "upgrade"]) delete headers[name];
  const upstream = http.request({
    hostname: target.hostname,
    port: target.port,
    path: `${target.pathname}${target.search}`,
    method: req.method,
    headers,
    timeout: 30000,
  }, response => {
    res.statusCode = response.statusCode || 502;
    for (const [name, value] of Object.entries(response.headers)) {
      if (value !== undefined && !["connection", "transfer-encoding", "keep-alive"].includes(name.toLowerCase())) res.setHeader(name, value);
    }
    response.pipe(res);
  });
  upstream.on("timeout", () => upstream.destroy(new Error("API cục bộ quá thời gian.")));
  upstream.on("error", error => {
    if (!res.headersSent) res.status(503).json({ error: `Không truy cập được dữ liệu cục bộ: ${error.message}` });
    else res.destroy(error);
  });
  req.on("aborted", () => upstream.destroy());
  req.pipe(upstream);
}

async function startLocalUiServer() {
  const web = express();
  web.disable("x-powered-by");
  web.use(express.urlencoded({ extended: false, limit: "8kb" }));
  web.all(/^\/api(?:\/|$)/, proxyApi);
  web.use(express.static(publicDir, {
    etag: true,
    setHeaders(res, filePath) {
      if (["index.html", "setup.html", "sw.js", "manifest.webmanifest"].some(name => filePath.endsWith(name))) res.setHeader("Cache-Control", "no-cache");
      if (filePath.endsWith("sw.js")) res.setHeader("Service-Worker-Allowed", "/");
    },
  }));
  web.get("/", (_req, res) => res.sendFile(path.join(publicDir, "index.html")));
  web.use((_req, res) => res.status(404).send("Không tìm thấy trang."));
  await new Promise((resolve, reject) => {
    localServer = web.listen(LOCAL_PORT, "127.0.0.1", resolve);
    localServer.once("error", reject);
  });
}

function lanIPv4() {
  const interfaces = os.networkInterfaces();
  for (const entries of Object.values(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === "IPv4" && !entry.internal && entry.address) return entry.address;
    }
  }
  return "127.0.0.1";
}

function lanPage(files = [], message = "", url = "", qrDataUrl = "") {
  const safeFiles = files.map(name => `<li><a href="/files/${encodeURIComponent(name)}" download>${name}</a></li>`).join("");
  return `<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gửi và nhận backup Phiếu giao hàng</title><style>body{font-family:Arial,sans-serif;background:#fdfbf7;color:#3c2415;margin:0;padding:20px}main{max-width:560px;margin:auto;background:#fff;border:1px solid #e7dcc0;border-radius:16px;padding:20px;box-shadow:0 8px 30px #3c241522}h1{font-size:22px;margin:0 0 8px}p{line-height:1.5;color:#5b5148}.code{font-size:28px;letter-spacing:8px;font-weight:800;background:#fffbeb;border:1px dashed #3c2415;border-radius:12px;padding:14px;text-align:center;margin:16px 0}.field{display:block;width:100%;box-sizing:border-box;padding:12px;border:1px solid #d8c9ad;border-radius:10px;margin:8px 0;font-size:16px}button{width:100%;padding:13px;border:0;border-radius:999px;background:#3c2415;color:#fff;font-weight:700;font-size:15px}small{color:#7b6d60}.ok{background:#ecfdf5;color:#166534;padding:12px;border-radius:10px}.files{padding-left:20px}.qr{text-align:center;margin:14px 0}.qr img{width:220px;height:220px;border:8px solid #fff;box-shadow:0 2px 12px #0002}.url{word-break:break-all;font-size:12px;background:#f8f5ee;padding:8px;border-radius:8px}</style><main><h1>Gửi và nhận backup qua Wi‑Fi</h1><p>Hai thiết bị chỉ cần cùng Wi‑Fi, không cần Internet. Có thể gửi <b>iPhone → máy tính</b> hoặc <b>máy tính → iPhone</b>. Trong PWA iPhone bấm <b>Quét Mã</b> để quét QR, hoặc mở địa chỉ bên dưới.</p><div class="qr"><img src="${qrDataUrl}" alt="QR địa chỉ LAN"><div class="url">${url}</div></div><div class="code">${lanTransferCode || "------"}</div><form id="f"><input class="field" id="code" inputmode="numeric" maxlength="6" value="${lanTransferCode || ""}" placeholder="Nhập mã 6 số" required><input class="field" id="file" type="file" accept=".json,application/json" required><button>Gửi file backup vào thiết bị kia</button></form><div id="m">${message}</div><h3>File đã nhận — bấm tên file để tải về</h3><ul class="files">${safeFiles || "<li>Chưa có file nào</li>"}</ul><small>Mã đổi khi mở lại EXE. File được lưu trong thư mục dữ liệu của EXE; thiết bị kia có thể tải file từ danh sách bên dưới.</small><script>f.addEventListener('submit',async e=>{e.preventDefault();const file=document.getElementById('file').files[0];const code=document.getElementById('code').value.trim();if(!file)return;m.textContent='Đang gửi...';try{const backup=await file.text();const r=await fetch('/receive',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,backup,fileName:file.name})});const d=await r.json();if(!r.ok)throw Error(d.error||'Không gửi được');m.className='ok';m.textContent='Đã nhận file: '+d.fileName+'. Có thể bấm tên file bên dưới để tải về.';setTimeout(()=>location.reload(),700)}catch(err){m.className='ok';m.textContent=err.message}})</script></main></html>`;
}

async function startLanTransferServer() {
  lanInboxDir = path.join(dataDir, "lan-inbox");
  fs.mkdirSync(lanInboxDir, { recursive: true });
  lanTransferCode = String(Math.floor(100000 + Math.random() * 900000));
  const url = `http://${lanIPv4()}:${LAN_PORT}/?code=${lanTransferCode}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 260, margin: 1, errorCorrectionLevel: "M" });
  const lan = express();
  lan.disable("x-powered-by");
  lan.use(express.json({ limit: "12mb" }));
  lan.get("/", (_req, res) => {
    const files = fs.readdirSync(lanInboxDir).filter(name => name.endsWith(".json")).sort().reverse();
    res.type("html").send(lanPage(files, "", url, qrDataUrl));
  });
  lan.post("/receive", (req, res) => {
    if (String(req.body?.code || "") !== lanTransferCode) return res.status(403).json({ error: "Mã 6 số không đúng hoặc đã hết hiệu lực." });
    let parsed;
    try { parsed = JSON.parse(String(req.body?.backup || "")); } catch { return res.status(400).json({ error: "File backup không phải JSON hợp lệ." }); }
    if (!parsed || typeof parsed !== "object") return res.status(400).json({ error: "Nội dung backup không hợp lệ." });
    const original = String(req.body?.fileName || "backup.json").replace(/[^a-z0-9._-]+/gi, "-").slice(0, 100) || "backup.json";
    const fileName = `${Date.now()}-${original.endsWith(".json") ? original : `${original}.json`}`;
    fs.writeFileSync(path.join(lanInboxDir, fileName), JSON.stringify(parsed, null, 2), "utf8");
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("pgh:lan-received", { fileName, path: path.join(lanInboxDir, fileName) });
    res.json({ ok: true, fileName });
  });
  lan.get("/files/:name", (req, res) => {
    const name = path.basename(req.params.name);
    const target = path.join(lanInboxDir, name);
    if (!name.endsWith(".json") || !fs.existsSync(target)) return res.status(404).send("Không tìm thấy file.");
    res.download(target, name);
  });
  await new Promise((resolve, reject) => { lanServer = lan.listen(LAN_PORT, "0.0.0.0", resolve); lanServer.once("error", reject); });
}

function loadLocal(pathname = "/") {
  if (mainWindow && !mainWindow.isDestroyed()) {
    const url = new URL(pathname, LOCAL_ORIGIN);
    url.searchParams.set("local", "1");
    mainWindow.loadURL(url.href);
  }
}

async function getInitialRoute() {
  return "/";
}

function uniquePath(filePath) {
  if (!fs.existsSync(filePath)) return filePath;
  const parsed = path.parse(filePath);
  let index = 2;
  while (fs.existsSync(path.join(parsed.dir, `${parsed.name}-${index}${parsed.ext}`))) index++;
  return path.join(parsed.dir, `${parsed.name}-${index}${parsed.ext}`);
}

async function backupData() {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const defaultPath = path.join(app.getPath("documents"), `phieu-giao-hang-${stamp}.sqlite`);
  const choice = await dialog.showSaveDialog(mainWindow, {
    title: "Sao lưu dữ liệu phiếu giao hàng",
    defaultPath,
    filters: [{ name: "SQLite database", extensions: ["sqlite"] }],
  });
  if (choice.canceled || !choice.filePath) return;
  const destination = uniquePath(choice.filePath);
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  const db = new Database(databasePath);
  try {
    db.exec("PRAGMA busy_timeout=5000;");
    db.exec(`VACUUM INTO '${destination.replaceAll("'", "''")}'`);
  } finally { db.close(); }
  await dialog.showMessageBox(mainWindow, {
    type: "info",
    title: "Sao lưu hoàn tất",
    message: "Đã sao lưu dữ liệu.",
    detail: `Tệp: ${destination}`,
  });
}

ipcMain.handle("pgh:print", async (event, request = {}) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) {
    throw new Error("Không thể in từ cửa sổ không hợp lệ.");
  }
  if (printDialogActive) return { ok: false, busy: true };
  printDialogActive = true;
  try {
    return await new Promise(resolve => {
      let settled = false;
      const finish = result => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve(result);
      };
      const timeout = setTimeout(() => finish({ ok: false, error: "Hộp thoại in đã quá thời gian chờ." }), 300000);
      try {
        event.sender.print({
          silent: false,
          printBackground: true,
          landscape: false,
          pageSize: request.paper === "A5" ? "A5" : "A4",
        }, (success, failureReason) => {
          if (success) finish({ ok: true });
          else if (failureReason) finish({ ok: false, error: String(failureReason) });
          else finish({ ok: false, canceled: true });
        });
      } catch (error) {
        finish({ ok: false, error: error?.message || String(error) });
      }
    });
  } finally {
    printDialogActive = false;
  }
});

ipcMain.handle("pgh:save-pdf", async (event, request = {}) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) {
    throw new Error("Không thể lưu PDF từ cửa sổ không hợp lệ.");
  }
  const stem = String(request.fileName || "Phieu-giao-hang")
    .replace(/[^a-z0-9._-]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 100) || "Phieu-giao-hang";
  const choice = await dialog.showSaveDialog(mainWindow, {
    title: "Lưu phiếu giao hàng thành PDF",
    defaultPath: path.join(app.getPath("documents"), `${stem}.pdf`),
    filters: [{ name: "Tệp PDF", extensions: ["pdf"] }],
  });
  if (choice.canceled || !choice.filePath) return { ok: true, canceled: true };

  const extension = path.extname(choice.filePath);
  const filePath = extension.toLowerCase() === ".pdf"
    ? choice.filePath
    : `${extension ? choice.filePath.slice(0, -extension.length) : choice.filePath}.pdf`;
  const pdf = await mainWindow.webContents.printToPDF({
    landscape: false,
    margins: { top: 0, bottom: 0, left: 0, right: 0 },
    pageSize: request.paper === "A5" ? "A5" : "A4",
    printBackground: true,
  });
  await fs.promises.writeFile(filePath, pdf);
  return { ok: true, filePath };
});

ipcMain.handle("pgh:lan-info", () => ({ ip: lanIPv4(), port: LAN_PORT, code: lanTransferCode, url: `http://${lanIPv4()}:${LAN_PORT}/`, inboxDir: lanInboxDir }));
ipcMain.handle("pgh:open-lan-page", () => shell.openExternal(`http://127.0.0.1:${LAN_PORT}/?code=${lanTransferCode}`));
ipcMain.handle("pgh:open-lan-inbox", () => shell.openPath(lanInboxDir));

function createMenu() {
  const menu = Menu.buildFromTemplate([
    { label: "Tệp", submenu: [
      { label: "Sao lưu dữ liệu…", click: () => backupData().catch(error => dialog.showErrorBox("Sao lưu thất bại", error.message)) },
      { label: "Mở thư mục dữ liệu…", click: () => shell.openPath(dataDir) },
      { type: "separator" },
      { role: "reload", label: "Tải lại" },
      { role: "quit", label: "Thoát" },
    ] },
    { label: "Trợ giúp", submenu: [
      { label: "Thông tin ứng dụng", click: () => dialog.showMessageBox(mainWindow, {
        type: "info",
        title: PRODUCT_NAME,
        message: PRODUCT_NAME,
        detail: `Dữ liệu chỉ lưu trên máy này. Không cần Internet hay server riêng.\n\nVị trí dữ liệu: ${dataDir}`,
      }) },
    ] },
  ]);
  Menu.setApplicationMenu(menu);
}

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 900,
    minHeight: 680,
    title: PRODUCT_NAME,
    backgroundColor: "#fdfbf7",
    autoHideMenuBar: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://")) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith(`${LOCAL_ORIGIN}/`)) event.preventDefault();
  });
  mainWindow.on("closed", () => { mainWindow = null; });
  loadLocal(await getInitialRoute());
}

app.setName(PRODUCT_NAME);
app.setAppUserModelId("vn.caferunam.phieugiaohang");
const hasSingleInstance = app.requestSingleInstanceLock();
if (!hasSingleInstance) {
  app.quit();
} else {
  app.on("second-instance", () => { if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); } });
  app.whenReady().then(async () => {
    // Prevent old app-shell service workers from showing stale/role-limited UI after an update.
    // The durable SQLite database and user data are stored outside Chromium storage and are untouched.
    await session.defaultSession.clearStorageData({ storages: ["serviceworkers", "cachestorage"] });
    await startEmbeddedApi();
    await startLocalUiServer();
    await startLanTransferServer();
    createMenu();
    session.defaultSession.setPermissionRequestHandler((_contents, permission, callback) => callback(permission === "media"));
    await createWindow();
    app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow().catch(error => dialog.showErrorBox(PRODUCT_NAME, error.message)); });
  }).catch(error => {
    dialog.showErrorBox(PRODUCT_NAME, `Không khởi động được ứng dụng hoặc database cục bộ: ${error.message}`);
    app.quit();
  });
}

app.on("before-quit", event => {
  if (quitting) return;
  quitting = true;
  if (localServer) localServer.close();
  if (lanServer) lanServer.close();
  if (backendModule?.shutdownEmbeddedServer) {
    event.preventDefault();
    backendModule.shutdownEmbeddedServer().catch(() => {}).finally(() => app.quit());
  }
});
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
