const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("pghDesktop", Object.freeze({
  savePdf: options => ipcRenderer.invoke("pgh:save-pdf", options),
  print: options => ipcRenderer.invoke("pgh:print", options),
  getLanInfo: () => ipcRenderer.invoke("pgh:lan-info"),
  openLanPage: () => ipcRenderer.invoke("pgh:open-lan-page"),
  openLanInbox: () => ipcRenderer.invoke("pgh:open-lan-inbox"),
  onLanReceived: callback => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on("pgh:lan-received", listener);
    return () => ipcRenderer.removeListener("pgh:lan-received", listener);
  },
}));
