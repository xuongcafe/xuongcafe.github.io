RUNAM DESKTOP - GIAO DIỆN MOBILE HIỆN TẠI / WINDOWS 7 & 10 64-BIT

ĐÃ GHÉP
- public/app.js: giao diện RUNAM bản mobile được dùng làm giao diện chung.
- desktop/main.cjs + desktop/preload.cjs: vỏ Electron và các chức năng in/PDF/Wi-Fi LAN.
- server/server.mjs + SQLite: lưu dữ liệu cục bộ trên máy tính.
- Cơ sở dữ liệu được lưu tại thư mục userData của Windows, tách khỏi thư mục cài đặt.

TƯƠNG THÍCH
- Electron 22.3.27 được ghim để giữ khả năng chạy trên Windows 7 64-bit.
- Cùng bộ cài x64 hướng tới Windows 7 64-bit và Windows 10 64-bit.
- Windows 7 cần được cập nhật các bản nền tảng/chứng thư hệ thống cần thiết; máy quá cũ có thể thiếu thành phần hệ thống.

TẠO FILE EXE/SETUP
1. Dùng máy Windows 10/11 64-bit để build (không build trực tiếp trên máy Windows 7).
2. Cài Node.js 16.x 64-bit và Git nếu cần.
3. Giải nén toàn bộ thư mục này.
4. Chạy tệp BUILD-WIN.bat và chờ hoàn tất.
5. File cài đặt xuất hiện trong thư mục dist. (Có thể chạy thủ công: npm install rồi npm run dist:win.)

LƯU Ý QUAN TRỌNG
- Đây là bộ mã nguồn đã ghép và cấu hình đóng gói, chưa phải file Setup.exe đã build.
- better-sqlite3 là module native; npm install phải chạy trên Windows x64 để electron-builder biên dịch/rebuild đúng ABI Electron 22.
- Không xóa thư mục dữ liệu RUNAM trong %APPDATA% khi cập nhật ứng dụng. Cơ sở dữ liệu hiện tại nằm trong thư mục userData/data/pgh.sqlite.
- Trước khi cài bản mới trên máy đang sử dụng, hãy sao lưu dữ liệu từ menu Tệp > Sao lưu dữ liệu.
- Không thử cài đè lên máy đang có dữ liệu thật trước khi kiểm tra bản sao lưu và chạy thử trên máy phụ.
