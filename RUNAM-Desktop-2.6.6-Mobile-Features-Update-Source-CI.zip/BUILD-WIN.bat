@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =============================================
echo   RUNAM - TAO BO CAI DAT WINDOWS 7/10 x64
echo =============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Chua cai Node.js. Hay cai Node.js 16.x 64-bit truoc.
  pause
  exit /b 1
)
node -v
echo.
echo Dang cai thu vien va rebuild SQLite cho Electron...
call npm install
if errorlevel 1 (
  echo Loi npm install. Kiem tra ket noi Internet va Node.js 16.x 64-bit.
  pause
  exit /b 1
)
echo.
echo Dang dong goi bo cai x64...
call npm run dist:win
if errorlevel 1 (
  echo Dong goi that bai. Xem loi o phia tren.
  pause
  exit /b 1
)
echo.
echo HOAN TAT. Mo thu muc dist de lay file RUNAM-Setup.
pause
