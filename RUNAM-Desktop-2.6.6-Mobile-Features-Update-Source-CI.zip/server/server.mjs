import express from "express";
import Database from "better-sqlite3";
import { createHash, randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { readFile } from "node:fs/promises";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const scrypt = promisify(scryptCallback);
const cookieName = "webdev_app_session";
const sessionLifetimeSeconds = 7 * 24 * 60 * 60;
const cookieSecure = process.env.COOKIE_SECURE !== "false";
const localNoAuth = process.env.PGH_LOCAL_NO_AUTH === "1";
const localAdminUser = { username: "admin", email: "", role: "admin", active: true, createdAt: null, lastSignedIn: null };
const nowSql = () => new Date();
function isLoopbackRequest(req) {
  const address = String(req.socket?.remoteAddress || "").toLowerCase();
  return address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";
}

const dataDir = path.resolve(process.env.DATA_DIR || path.join(here, "data"));
mkdirSync(dataDir, { recursive: true });
const databasePath = path.join(dataDir, "pgh.sqlite");
const database = new Database(databasePath);
database.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");

function bindValues(params) {
  return Array.from(params || [], value => value instanceof Date ? value.toISOString() : value);
}
function runSql(db, sql, params = []) {
  const normalized = String(sql).replace(/\s+FOR UPDATE\b/gi, "");
  const statement = db.prepare(normalized);
  const values = bindValues(params);
  if (/^\s*(SELECT|WITH|PRAGMA)\b/i.test(normalized)) return [statement.all(...values)];
  return [statement.run(...values)];
}
function isDuplicateError(error) {
  return /UNIQUE constraint failed|PRIMARY KEY constraint failed/i.test(String(error?.message || ""));
}
function configureConnection(db) {
  db.exec("PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA synchronous=FULL;");
  return {
    query: async (sql, params = []) => runSql(db, sql, params),
    execute: async (sql, params = []) => runSql(db, sql, params),
    beginTransaction: async () => db.exec("BEGIN IMMEDIATE"),
    commit: async () => db.exec("COMMIT"),
    rollback: async () => db.exec("ROLLBACK"),
    release: () => db.close(),
  };
}
const pool = {
  query: async (sql, params = []) => runSql(database, sql, params),
  execute: async (sql, params = []) => runSql(database, sql, params),
  getConnection: async () => configureConnection(new Database(databasePath)),
};

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(express.json({ limit: "2mb", strict: true }));

const DEFAULT_LABELS = {
  mainTitle: "PHIẾU GIAO HÀNG", soPhieu: "SỐ PHIẾU", soPhieuXuat: "SỐ PHIẾU XUẤT", soPO: "SỐ PO",
  ngayGiao: "NGÀY GIAO", khachHang: "KHÁCH HÀNG", maKhach: "Mã Khách", tenDaiLy: "Tên Đại Lý",
  diaChi: "Địa Chỉ", nguoiNhan: "Người Nhận", sdtNhan: "SĐT Người Nhận", loaiXe: "Loại Xe",
  chiTietSP: "CHI TIẾT SẢN PHẨM", stt: "STT", maKho: "Mã Kho", maFast: "Mã Fast", tenSP: "Tên SP", quyCach: "Quy Cách",
  ngaySX: "Ngày SX", soGoi: "Số Gói", soKg: "Số Kg", tong: "Tổng", tongSoLuong: "Tổng số lượng", tongKhoiLuong: "Tổng khối lượng", btnTaoPhieu: "Tạo phiếu & Lưu",
  btnXemTruoc: "Xem trước A4/A5", btnQuet: "Quét Mã", nguoiLap: "Người Lập", nguoiGiao: "Người Giao",
  nguoiNhanFooter: "Người Nhận", lichSu: "LỊCH SỬ PHIẾU", thongTinPhieu: "THÔNG TIN PHIẾU",
  thongTinKhach: "THÔNG TIN KHÁCH HÀNG",
};
const DEFAULT_THEME = { main: "#3C2415", beige: "#FFFBEB", bg: "#FDFBF7", text: "#111827", font: "Inter", fontScale: 1, logoSize: 76, printLogoSize: 40, printQrSize: 28, fontWeight: 700, boxBg: "#FFFFFF", boxBgInfo: "#FFFFFF", boxBgCustomer: "#FFFFFF" };
const DEFAULT_TITLE_SIZES = { mainTitle: 20, soPhieu: 11, soPhieuXuat: 11, soPO: 11, ngayGiao: 11, khachHang: 12, chiTietSP: 12, tableHeader: 11, tong: 12, lichSu: 12, printCompany: 16, printCompanyMeta: 10, printSection: 10, printInfoLabel: 11, printInfoValue: 11, printCustomerTitle: 10, printCustomerName: 13, printCustomerBody: 11, printTableHeader: 11, printTableBody: 11, printFooter: 11, printBatchTotal: 13, printGross: 13, printSignature: 11, printSignatureHint: 9, printQr: 9 };
const DEFAULT_HIDE = {
  LogoIn: true, TenXuongIn: true, SDTIn: true, EmailIn: true, DiaChiIn: true,
  SoPhieuIn: true, SoPhieuXuatIn: true, SoPOIn: true, NgayGiaoIn: true, QRIn: true,
  MaKhachIn: true, TenDaiLyIn: true, DiaChiKhachIn: true, NguoiNhanIn: true, SDTNhanIn: true, LoaiXeIn: true,
  CotSTTIn: true, MaKhoIn: true, MaFastIn: true, TenSPIn: true, QuyCachIn: true, NgaySXIn: true, SoGoiIn: true, SoKgIn: true, TongIn: true, ChuKyIn: true, NguoiGiaoKyIn: true, NguoiNhanKyIn: true,
};

function sha256(value) { return createHash("sha256").update(String(value)).digest("hex"); }
function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]));
  return value;
}
function stableJson(value) { return JSON.stringify(stable(value)); }
function parseJson(value, fallback = null) {
  if (value == null) return fallback;
  if (typeof value === "object") return value;
  try { return JSON.parse(String(value)); } catch { return fallback; }
}
function cleanUsername(value) {
  const username = String(value || "").trim().toLowerCase();
  return /^[a-z0-9._-]{3,32}$/.test(username) ? username : "";
}
function publicUser(row) {
  return row ? {
    username: row.username, email: row.email || "", role: row.role,
    active: Boolean(row.active), createdAt: row.created_at ? new Date(row.created_at).toISOString() : null,
    lastSignedIn: row.last_signed_in ? new Date(row.last_signed_in).toISOString() : null,
  } : null;
}
function readCookie(req, name) {
  const cookies = String(req.headers.cookie || "").split(";");
  for (const part of cookies) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    if (part.slice(0, separator).trim() === name) return decodeURIComponent(part.slice(separator + 1).trim());
  }
  return "";
}
function setSessionCookie(res, token) {
  const attributes = [`${cookieName}=${encodeURIComponent(token)}`, "Path=/", "HttpOnly", `SameSite=${cookieSecure ? "None" : "Lax"}`, `Max-Age=${sessionLifetimeSeconds}`];
  if (cookieSecure) attributes.push("Secure");
  else attributes[3] = "SameSite=Lax";
  res.setHeader("Set-Cookie", attributes.join("; "));
}
function clearSessionCookie(res) {
  res.setHeader("Set-Cookie", `${cookieName}=; Path=/; HttpOnly; SameSite=${cookieSecure ? "None; Secure" : "Lax"}; Max-Age=0`);
}
function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}
function needUser(req, res) {
  if (!req.pghUser) { res.status(401).json({ error: "Vui lòng đăng nhập lại." }); return false; }
  return true;
}
function needAdmin(req, res) {
  if (!needUser(req, res)) return false;
  if (req.pghUser.role !== "admin") { res.status(403).json({ error: "Chỉ Admin được phép thực hiện thao tác này." }); return false; }
  return true;
}
function validatePassword(password) { return typeof password === "string" && password.length >= 12 && password.length <= 256; }
async function hashPassword(password) {
  const salt = randomBytes(16);
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${Buffer.from(derived).toString("hex")}`;
}
async function verifyPassword(password, stored) {
  const [algorithm, saltHex, hashHex] = String(stored || "").split("$");
  if (algorithm !== "scrypt" || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, "hex");
  const actual = Buffer.from(await scrypt(String(password), Buffer.from(saltHex, "hex"), expected.length));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
async function transaction(work) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await work(conn);
    await conn.commit();
    return result;
  } catch (error) {
    try { await conn.rollback(); } catch {}
    throw error;
  } finally { conn.release(); }
}
async function addAudit(conn, actor, action, entityType, entityKey, before, after) {
  await conn.execute(
    "INSERT INTO audit_events (actor_username, action, entity_type, entity_key, before_json, after_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [actor, action, entityType, String(entityKey || ""), before == null ? null : JSON.stringify(before), after == null ? null : JSON.stringify(after), nowSql()],
  );
}
function settingsValue(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw Object.assign(new Error("Cấu hình không hợp lệ."), { status: 400 });
  const result = { language: ["vi", "en", "it"].includes(input.language) ? input.language : "vi", labels: { ...DEFAULT_LABELS }, theme: { ...DEFAULT_THEME }, titleSizes: { ...DEFAULT_TITLE_SIZES }, hide: { ...DEFAULT_HIDE }, company: { tenXuong: "XƯỞNG RANG CAFE NGUYÊN CHẤT", sdtXuong: "0909 888 777", emailXuong: "xuong@caphe.com", diaChiXuong: "123 Lê Văn Sỹ, Phú Nhuận, HCM", logo: null } };
  if (input.labels && typeof input.labels === "object" && !Array.isArray(input.labels)) {
    for (const key of Object.keys(DEFAULT_LABELS)) if (typeof input.labels[key] === "string") result.labels[key] = input.labels[key].slice(0, 120);
  }
  if (input.theme && typeof input.theme === "object" && !Array.isArray(input.theme)) {
    for (const key of ["main", "beige", "bg", "text", "boxBg", "boxBgInfo", "boxBgCustomer"]) {
      const color = input.theme[key];
      if (typeof color === "string" && /^#[0-9a-f]{6}$/i.test(color)) result.theme[key] = color;
    }
    if (["Inter", "Playfair Display", "Roboto", "Be Vietnam Pro"].includes(input.theme.font)) result.theme.font = input.theme.font;
    if (Number.isFinite(Number(input.theme.fontScale))) result.theme.fontScale = Math.max(0.8, Math.min(1.4, Number(input.theme.fontScale)));
    if (Number.isFinite(Number(input.theme.logoSize))) result.theme.logoSize = Math.max(48, Math.min(180, Number(input.theme.logoSize)));
    if (Number.isFinite(Number(input.theme.printLogoSize))) result.theme.printLogoSize = Math.max(24, Math.min(80, Number(input.theme.printLogoSize)));
    if (Number.isFinite(Number(input.theme.printQrSize))) result.theme.printQrSize = Math.max(18, Math.min(50, Number(input.theme.printQrSize)));
    if ([500, 600, 700, 800].includes(Number(input.theme.fontWeight))) result.theme.fontWeight = Number(input.theme.fontWeight);
  }
  if (input.titleSizes && typeof input.titleSizes === "object" && !Array.isArray(input.titleSizes)) {
    for (const key of Object.keys(DEFAULT_TITLE_SIZES)) if (Number.isFinite(Number(input.titleSizes[key]))) result.titleSizes[key] = Math.max(8, Math.min(32, Number(input.titleSizes[key])));
  }
  if (input.hide && typeof input.hide === "object" && !Array.isArray(input.hide)) {
    for (const key of Object.keys(DEFAULT_HIDE)) if (typeof input.hide[key] === "boolean") result.hide[key] = input.hide[key];
  }
  if (input.company && typeof input.company === "object" && !Array.isArray(input.company)) {
    for (const [key, max] of Object.entries({ tenXuong: 160, sdtXuong: 64, emailXuong: 254, diaChiXuong: 300 })) {
      if (typeof input.company[key] === "string") result.company[key] = input.company[key].trim().slice(0, max);
    }
    const logo = input.company.logo;
    if (logo === null || logo === "") result.company.logo = null;
    else if (typeof logo === "string" && logo.length <= 900000 && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(logo)) result.company.logo = logo;
  }
  return result;
}

function normalizeSearchText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[đĐ]/g, match => match === "Đ" ? "D" : "d")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}
function ticketSearchText(ticket) {
  const customer = ticket?.customer || {};
  const values = [
    ticket?.soPhieu, ticket?.soPhieuXuat, ticket?.soPO,
    customer?.maKhach, customer?.code, customer?.tenDaiLy,
    customer?.diaChi, customer?.nguoiNhan, customer?.sdt,
    customer?.loaiXe,
    ...(Array.isArray(ticket?.products) ? ticket.products.flatMap(item => [item?.tenSP, item?.maKho, item?.maFast]) : []),
  ];
  return normalizeSearchText(values.filter(value => value != null && value !== "").join(" "));
}
function saveTicketSearchIndex(conn, ticket, owner) {
  const text = ticketSearchText(ticket);
  return conn.execute(
    "INSERT INTO ticket_search_index(owner_username,ticket_id,search_text) VALUES(?,?,?) ON CONFLICT(owner_username,ticket_id) DO UPDATE SET search_text=excluded.search_text",
    [owner, ticket.id, text],
  );
}

function ticketMonth(value) {
  const match = String(value || "").trim().match(/^(\d{4})-(\d{2})/);
  if (!match || Number(match[2]) < 1 || Number(match[2]) > 12) return "";
  return `${match[1]}-${match[2]}`;
}
function ticketNumberGrams(value) {
  const normalized = String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  const grams = new Set();
  for (const width of [2, 3]) {
    for (let index = 0; index <= normalized.length - width; index++) grams.add(normalized.slice(index, index + width));
  }
  return Array.from(grams);
}
async function applyMigration() {
  const existingTable = database.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ticket_history'").get();
  if (existingTable) {
    const columns = database.prepare("PRAGMA table_info(ticket_history)").all();
    if (!columns.some(column => column.name === "delivery_month")) database.exec("ALTER TABLE ticket_history ADD COLUMN delivery_month TEXT");
  }
  const sql = await readFile(path.join(here, "migrations/001-sqlite.sql"), "utf8");
  database.exec(sql);
  database.exec(`CREATE TABLE IF NOT EXISTS ticket_search_index (
    owner_username TEXT NOT NULL,
    ticket_id TEXT NOT NULL,
    search_text TEXT NOT NULL,
    PRIMARY KEY (owner_username, ticket_id),
    FOREIGN KEY (owner_username, ticket_id) REFERENCES ticket_history(owner_username, ticket_id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_ticket_search_owner ON ticket_search_index(owner_username, ticket_id);`);
  // Use an app-specific metadata table; legacy PGH databases may have an unrelated schema_migrations table.
  const prior = database.prepare("SELECT version FROM pgh_desktop_migrations WHERE version=2").get();
  if (!prior) {
    const updateMonth = database.prepare("UPDATE ticket_history SET delivery_month=? WHERE owner_username=? AND ticket_id=?");
    const addGram = database.prepare("INSERT OR IGNORE INTO ticket_number_grams(owner_username,ticket_id,gram) VALUES(?,?,?)");
    const migrateBatch = database.transaction(rows => {
      for (const row of rows) {
        const ticket = parseJson(row.payload, {});
        const month = ticketMonth(ticket?.ngayGiao) || ticketMonth(row.created_at);
        if (month) updateMonth.run(month, row.owner_username, row.ticket_id);
        for (const gram of ticketNumberGrams(row.ticket_no)) addGram.run(row.owner_username, row.ticket_id, gram);
      }
    });
    let lastRowId = 0;
    while (true) {
      const rows = database.prepare("SELECT rowid AS row_id,owner_username,ticket_id,ticket_no,payload,created_at FROM ticket_history WHERE rowid>? ORDER BY rowid LIMIT 200").all(lastRowId);
      if (!rows.length) break;
      migrateBatch(rows);
      lastRowId = rows[rows.length - 1].row_id;
      await new Promise(resolve => setImmediate(resolve));
    }
    database.prepare("INSERT OR IGNORE INTO pgh_desktop_migrations(version,applied_at) VALUES(2,?)").run(new Date().toISOString());
  }
  const searchMigration = database.prepare("SELECT version FROM pgh_desktop_migrations WHERE version=3").get();
  if (!searchMigration) {
    const insert = database.prepare("INSERT OR REPLACE INTO ticket_search_index(owner_username,ticket_id,search_text) VALUES(?,?,?)");
    const backfill = database.transaction(items => {
      for (const row of items) insert.run(row.owner_username, row.ticket_id, ticketSearchText(parseJson(row.payload, {})));
    });
    let lastRowId = 0;
    while (true) {
      const rows = database.prepare("SELECT rowid AS row_id,owner_username,ticket_id,payload FROM ticket_history WHERE rowid>? ORDER BY rowid LIMIT 500").all(lastRowId);
      if (!rows.length) break;
      backfill(rows);
      lastRowId = rows[rows.length - 1].row_id;
    }
    database.prepare("INSERT OR IGNORE INTO pgh_desktop_migrations(version,applied_at) VALUES(3,?)").run(new Date().toISOString());
  }
}

async function ensureLocalAdmin() {
  const [rows] = await pool.execute("SELECT username,role,active FROM app_users WHERE username=? LIMIT 1", [localAdminUser.username]);
  const now = nowSql();
  if (!rows.length) {
    const unavailablePasswordHash = await hashPassword(randomBytes(48).toString("base64url"));
    await transaction(async conn => {
      await conn.execute("INSERT INTO app_users (username,password_hash,email,role,active,created_at,updated_at) VALUES (?,?,NULL,'admin',1,?,?)", [localAdminUser.username, unavailablePasswordHash, now, now]);
      await addAudit(conn, localAdminUser.username, "local_admin_initialized", "system", "local-admin", null, { username: localAdminUser.username, role: "admin", loginRequired: false });
    });
  } else if (rows[0].role !== "admin" || !Boolean(rows[0].active)) {
    await transaction(async conn => {
      await conn.execute("UPDATE app_users SET role='admin',active=1,updated_at=? WHERE username=?", [now, localAdminUser.username]);
      await addAudit(conn, localAdminUser.username, "local_admin_privileges_restored", "account", localAdminUser.username, { role: rows[0].role, active: Boolean(rows[0].active) }, { role: "admin", active: true, loginRequired: false });
    });
  }
}

app.get("/api/health", asyncRoute(async (_req, res) => {
  await pool.query("SELECT 1");
  res.json({ ok: true, service: "pgh-v2" });
}));


app.use("/api", asyncRoute(async (req, _res, next) => {
  req.pghUser = null;
  if (localNoAuth) {
    req.pghUser = localAdminUser;
    return next();
  }
  const token = readCookie(req, cookieName);
  if (!token) return next();
  const hash = sha256(token);
  const [rows] = await pool.execute(
    "SELECT u.username, u.email, u.role, u.active, u.created_at, u.last_signed_in FROM app_sessions s JOIN app_users u ON u.username=s.username WHERE s.session_hash=? AND s.expires_at>? AND u.active=1 LIMIT 1",
    [hash, nowSql()],
  );
  if (rows.length) {
    req.pghUser = publicUser(rows[0]);
    req.sessionHash = hash;
  }
  next();
}));
app.use("/api", (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  if (req.get("X-PGH-Request") !== "1") return res.status(403).json({ error: "Yêu cầu không hợp lệ." });
  next();
});

app.post("/api/maintenance/optimize", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const pageSize = Number(database.pragma("page_size", { simple: true }) || 4096);
  const beforeBytes = Number(database.pragma("page_count", { simple: true }) || 0) * pageSize;
  database.pragma("wal_checkpoint(TRUNCATE)");
  database.exec("VACUUM");
  database.pragma("wal_checkpoint(TRUNCATE)");
  database.pragma("optimize");
  const afterBytes = Number(database.pragma("page_count", { simple: true }) || 0) * pageSize;
  res.json({ success: true, beforeBytes, afterBytes, freedBytes: Math.max(0, beforeBytes - afterBytes), message: "Đã tối ưu SQLite; phiếu và danh mục không bị xóa." });
}));
app.get("/api/setup/status", asyncRoute(async (req, res) => {
  const [rows] = await pool.query("SELECT COUNT(*) AS total FROM app_users");
  res.json({ setupRequired: Number(rows[0].total) === 0, canInitialize: isLoopbackRequest(req) });
}));
app.post("/api/setup/admin", asyncRoute(async (req, res) => {
  if (localNoAuth) return res.status(410).json({ error: "Ứng dụng đã vào thẳng với quyền Admin cục bộ; không cần tạo tài khoản." });
  if (!isLoopbackRequest(req)) return res.status(403).json({ error: "Admin đầu tiên chỉ có thể được tạo ngay trên máy chạy server." });
  const username = cleanUsername(req.body?.username);
  const password = req.body?.password;
  if (!username || username !== "admin") return res.status(400).json({ error: "Tài khoản Admin đầu tiên phải có tên admin." });
  if (!validatePassword(password)) return res.status(400).json({ error: "Mật khẩu cần từ 12 đến 256 ký tự." });
  const passwordHash = await hashPassword(password);
  try {
    await transaction(async conn => {
      const [existing] = await conn.query("SELECT username FROM app_users LIMIT 1 FOR UPDATE");
      if (existing.length) throw Object.assign(new Error("Thiết lập đã được hoàn tất; không thể tạo Admin đầu tiên lần nữa."), { status: 409 });
      const now = nowSql();
      await conn.execute("INSERT INTO app_users (username,password_hash,role,active,created_at,updated_at) VALUES (?,?, 'admin',1,?,?)", [username, passwordHash, now, now]);
      await addAudit(conn, username, "account_created", "account", username, null, { username, role: "admin", active: true, bootstrap: true });
    });
  } catch (error) { if (error.status) return res.status(error.status).json({ error: error.message }); throw error; }
  res.json({ ok: true });
}));

app.get("/api/auth/me", (req, res) => res.json({ user: req.pghUser || null }));
const loginAttempts = new Map();
app.post("/api/auth/login", asyncRoute(async (req, res) => {
  if (localNoAuth) return res.status(410).json({ error: "Đăng nhập đã tắt; ứng dụng luôn dùng quyền Admin cục bộ." });
  const username = cleanUsername(req.body?.username);
  const password = String(req.body?.password || "");
  const rateKey = `${req.ip}:${username || "invalid"}`;
  const attempt = loginAttempts.get(rateKey) || { count: 0, resetAt: Date.now() + 15 * 60 * 1000 };
  if (attempt.resetAt < Date.now()) { attempt.count = 0; attempt.resetAt = Date.now() + 15 * 60 * 1000; }
  if (attempt.count >= 10) return res.status(429).json({ error: "Thử đăng nhập quá nhiều lần. Hãy đợi 15 phút." });
  const [rows] = await pool.execute("SELECT username,password_hash,email,role,active,created_at,last_signed_in FROM app_users WHERE username=? LIMIT 1", [username || "__invalid__"]);
  const row = rows[0];
  const valid = row && Boolean(row.active) && await verifyPassword(password, row.password_hash);
  if (!valid) {
    attempt.count += 1; loginAttempts.set(rateKey, attempt);
    return res.status(401).json({ error: row && !row.active ? "Tài khoản đã bị khóa. Hãy liên hệ Admin." : "Tên tài khoản hoặc mật khẩu không đúng." });
  }
  loginAttempts.delete(rateKey);
  const rawToken = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + sessionLifetimeSeconds * 1000);
  await pool.execute("INSERT INTO app_sessions (session_hash,username,created_at,expires_at) VALUES (?,?,?,?)", [sha256(rawToken), username, nowSql(), expires]);
  await pool.execute("UPDATE app_users SET last_signed_in=?,updated_at=? WHERE username=?", [nowSql(), nowSql(), username]);
  setSessionCookie(res, rawToken);
  res.json({ user: { ...publicUser(row), username, role: row.role, active: true, lastSignedIn: nowSql().toISOString() } });
}));
app.post("/api/auth/logout", asyncRoute(async (req, res) => {
  if (req.sessionHash) await pool.execute("DELETE FROM app_sessions WHERE session_hash=?", [req.sessionHash]);
  clearSessionCookie(res);
  res.json({ success: true });
}));
app.post("/api/auth/password", asyncRoute(async (req, res) => {
  if (localNoAuth) return res.status(410).json({ error: "Chế độ không đăng nhập không dùng mật khẩu." });
  if (!needUser(req, res)) return;
  const current = String(req.body?.currentPassword || "");
  const next = req.body?.newPassword;
  const [rows] = await pool.execute("SELECT password_hash FROM app_users WHERE username=?", [req.pghUser.username]);
  if (!rows.length || !await verifyPassword(current, rows[0].password_hash)) return res.status(400).json({ error: "Mật khẩu hiện tại không đúng." });
  if (!validatePassword(next)) return res.status(400).json({ error: "Mật khẩu mới cần từ 12 đến 256 ký tự." });
  const passwordHash = await hashPassword(next);
  const rawToken = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + sessionLifetimeSeconds * 1000);
  await transaction(async conn => {
    await conn.execute("UPDATE app_users SET password_hash=?,updated_at=? WHERE username=?", [passwordHash, nowSql(), req.pghUser.username]);
    await conn.execute("DELETE FROM app_sessions WHERE username=?", [req.pghUser.username]);
    await conn.execute("INSERT INTO app_sessions (session_hash,username,created_at,expires_at) VALUES (?,?,?,?)", [sha256(rawToken), req.pghUser.username, nowSql(), expires]);
    await addAudit(conn, req.pghUser.username, "account_password_changed", "account", req.pghUser.username, { passwordChanged: false }, { passwordChanged: true });
  });
  setSessionCookie(res, rawToken);
  res.json({ success: true });
}));

app.get("/api/settings", (req, res) => {
  if (!needUser(req, res)) return;
  pool.execute("SELECT settings_json FROM app_settings WHERE setting_key='global' LIMIT 1").then(([rows]) => {
    res.json({ settings: rows.length ? settingsValue(parseJson(rows[0].settings_json)) : settingsValue({}) });
  }).catch(error => res.status(500).json({ error: "Không tải được cấu hình dùng chung." }));
});
app.put("/api/settings", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const incoming = req.body?.settings;
  const next = settingsValue(incoming);
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT settings_json FROM app_settings WHERE setting_key='global' FOR UPDATE");
    const before = rows.length ? settingsValue(parseJson(rows[0].settings_json)) : settingsValue({});
    if (stableJson(before) === stableJson(next)) return { settings: next, changed: false };
    await conn.execute("INSERT INTO app_settings (setting_key,settings_json,updated_by,updated_at) VALUES ('global',?,?,?) ON CONFLICT(setting_key) DO UPDATE SET settings_json=excluded.settings_json,updated_by=excluded.updated_by,updated_at=excluded.updated_at", [JSON.stringify(next), req.pghUser.username, nowSql()]);
    await addAudit(conn, req.pghUser.username, "settings_updated", "settings", "global", before, next);
    return { settings: next, changed: true };
  });
  res.json(result);
}));

app.get("/api/catalog", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const [[customers], [products]] = await Promise.all([
    pool.query("SELECT payload FROM catalog_customers WHERE deleted_at IS NULL ORDER BY customer_code"),
    pool.query("SELECT payload FROM catalog_products WHERE deleted_at IS NULL ORDER BY product_code"),
  ]);
  res.json({ customers: customers.map(row => parseJson(row.payload, {})), products: products.map(row => parseJson(row.payload, {})) });
}));
app.post("/api/catalog/customers", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const customer = req.body?.customer;
  const code = String(customer?.code || "").trim().toUpperCase();
  if (!customer || !code || !String(customer.tenDaiLy || "").trim()) return res.status(400).json({ error: "Khách hàng cần có mã và tên." });
  const saved = { ...customer, code };
  try {
    await transaction(async conn => {
      const [existing] = await conn.execute("SELECT payload,deleted_at FROM catalog_customers WHERE customer_code=? FOR UPDATE", [code]);
      if (existing.length && !existing[0].deleted_at) throw Object.assign(new Error("Mã khách hàng đã tồn tại."), { status: 409 });
      if (existing.length) await conn.execute("UPDATE catalog_customers SET payload=?,created_by=?,updated_at=?,deleted_at=NULL,deleted_by=NULL WHERE customer_code=?", [JSON.stringify(saved), req.pghUser.username, nowSql(), code]);
      else await conn.execute("INSERT INTO catalog_customers (customer_code,payload,created_by,created_at,updated_at) VALUES (?,?,?,?,?)", [code, JSON.stringify(saved), req.pghUser.username, nowSql(), nowSql()]);
      await addAudit(conn, req.pghUser.username, existing.length ? "customer_readded" : "customer_added", "customer", code, existing.length ? parseJson(existing[0].payload, {}) : null, saved);
    });
  } catch (error) { if (error.status) return res.status(error.status).json({ error: error.message }); if (isDuplicateError(error)) return res.status(409).json({ error: "Mã khách hàng đã tồn tại." }); throw error; }
  res.status(201).json({ customer: saved });
}));
app.post("/api/catalog/products", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const product = req.body?.product;
  const code = String(product?.maKho || "").trim().toUpperCase();
  if (!product || !code || !String(product.tenSP || "").trim()) return res.status(400).json({ error: "Sản phẩm cần có mã kho và tên." });
  const saved = { ...product, maKho: code };
  try {
    await transaction(async conn => {
      const [existing] = await conn.execute("SELECT payload,deleted_at FROM catalog_products WHERE product_code=? FOR UPDATE", [code]);
      if (existing.length && !existing[0].deleted_at) throw Object.assign(new Error("Mã sản phẩm đã tồn tại."), { status: 409 });
      if (existing.length) await conn.execute("UPDATE catalog_products SET payload=?,created_by=?,updated_at=?,deleted_at=NULL,deleted_by=NULL WHERE product_code=?", [JSON.stringify(saved), req.pghUser.username, nowSql(), code]);
      else await conn.execute("INSERT INTO catalog_products (product_code,payload,created_by,created_at,updated_at) VALUES (?,?,?,?,?)", [code, JSON.stringify(saved), req.pghUser.username, nowSql(), nowSql()]);
      await addAudit(conn, req.pghUser.username, existing.length ? "product_readded" : "product_added", "product", code, existing.length ? parseJson(existing[0].payload, {}) : null, saved);
    });
  } catch (error) { if (error.status) return res.status(error.status).json({ error: error.message }); if (isDuplicateError(error)) return res.status(409).json({ error: "Mã sản phẩm đã tồn tại." }); throw error; }
  res.status(201).json({ product: saved });
}));
async function updateCatalogItem(req, res, table, keyColumn, key, bodyKey, action, entityType) {
  if (!needAdmin(req, res)) return;
  const value = String(req.params[key] || "").trim().toUpperCase();
  const item = req.body?.[bodyKey];
  if (!item || (bodyKey === "customer" ? !String(item.tenDaiLy || "").trim() : !String(item.tenSP || "").trim())) return res.status(400).json({ error: "Thiếu thông tin bắt buộc." });
  const saved = { ...item, [keyColumn === "customer_code" ? "code" : "maKho"]: value };
  const result = await transaction(async conn => {
    const [rows] = await conn.execute(`SELECT payload FROM ${table} WHERE ${keyColumn}=? AND deleted_at IS NULL FOR UPDATE`, [value]);
    if (!rows.length) return null;
    const before = parseJson(rows[0].payload, {});
    await conn.execute(`UPDATE ${table} SET payload=?,updated_at=? WHERE ${keyColumn}=?`, [JSON.stringify(saved), nowSql(), value]);
    await addAudit(conn, req.pghUser.username, action, entityType, value, before, saved);
    return saved;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy mục danh mục." });
  res.json({ [bodyKey]: result });
}
app.put("/api/catalog/customers/:code", asyncRoute((req, res) => updateCatalogItem(req, res, "catalog_customers", "customer_code", "code", "customer", "customer_updated", "customer")));
app.put("/api/catalog/products/:code", asyncRoute((req, res) => updateCatalogItem(req, res, "catalog_products", "product_code", "code", "product", "product_updated", "product")));
async function deleteCatalogItem(req, res, table, keyColumn, key, action, entityType) {
  if (!needAdmin(req, res)) return;
  const value = String(req.params[key] || "").trim().toUpperCase();
  const result = await transaction(async conn => {
    const [rows] = await conn.execute(`SELECT payload FROM ${table} WHERE ${keyColumn}=? AND deleted_at IS NULL FOR UPDATE`, [value]);
    if (!rows.length) return null;
    const before = parseJson(rows[0].payload, {});
    await conn.execute(`UPDATE ${table} SET deleted_at=?,deleted_by=? WHERE ${keyColumn}=?`, [nowSql(), req.pghUser.username, value]);
    await addAudit(conn, req.pghUser.username, action, entityType, value, before, null);
    return true;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy mục danh mục." });
  res.json({ success: true });
}
app.delete("/api/catalog/customers/:code", asyncRoute((req, res) => deleteCatalogItem(req, res, "catalog_customers", "customer_code", "code", "customer_deleted", "customer")));
app.delete("/api/catalog/products/:code", asyncRoute((req, res) => deleteCatalogItem(req, res, "catalog_products", "product_code", "code", "product_deleted", "product")));
app.post("/api/catalog/import-local", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const customers = Array.isArray(req.body?.customers) ? req.body.customers.slice(0, 500) : [];
  const products = Array.isArray(req.body?.products) ? req.body.products.slice(0, 500) : [];
  let importedCustomers = 0, importedProducts = 0, mergedFastCodes = 0, rejected = 0;
  await transaction(async conn => {
    for (const item of customers) {
      const code = String(item?.code || "").trim().toUpperCase();
      if (!code || !String(item.tenDaiLy || "").trim()) { rejected++; continue; }
      try {
        const value = { ...item, code };
        await conn.execute("INSERT INTO catalog_customers (customer_code,payload,created_by,created_at,updated_at) VALUES (?,?,?,?,?)", [code, JSON.stringify(value), req.pghUser.username, nowSql(), nowSql()]);
        await addAudit(conn, req.pghUser.username, "customer_added", "customer", code, null, value); importedCustomers++;
      } catch (error) { if (isDuplicateError(error)) continue; throw error; }
    }
    for (const item of products) {
      const code = String(item?.maKho || "").trim().toUpperCase();
      if (!code || !String(item.tenSP || "").trim()) { rejected++; continue; }
      try {
        const value = { ...item, maKho: code };
        await conn.execute("INSERT INTO catalog_products (product_code,payload,created_by,created_at,updated_at) VALUES (?,?,?,?,?)", [code, JSON.stringify(value), req.pghUser.username, nowSql(), nowSql()]);
        await addAudit(conn, req.pghUser.username, "product_added", "product", code, null, value); importedProducts++;
      } catch (error) {
        if (!isDuplicateError(error)) throw error;
        const fastCode = String(item?.maFast || "").trim();
        if (!fastCode) continue;
        const [existingRows] = await conn.execute("SELECT payload,deleted_at FROM catalog_products WHERE product_code=?", [code]);
        if (!existingRows.length || existingRows[0].deleted_at) continue;
        const before = parseJson(existingRows[0].payload, {});
        if (String(before.maFast || "").trim()) continue;
        const merged = { ...before, maFast: fastCode };
        await conn.execute("UPDATE catalog_products SET payload=?,updated_at=? WHERE product_code=?", [JSON.stringify(merged), nowSql(), code]);
        await addAudit(conn, req.pghUser.username, "product_fast_code_added", "product", code, before, merged);
        mergedFastCodes++;
      }
    }
  });
  res.json({ importedCustomers, importedProducts, mergedFastCodes, rejected });
}));

function normalizeTicket(input, owner) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw Object.assign(new Error("Dữ liệu phiếu không hợp lệ."), { status: 400 });
  const id = String(input.id || randomUUID());
  if (id.length > 128 || !/^[a-zA-Z0-9._:-]+$/.test(id)) throw Object.assign(new Error("Mã phiếu không hợp lệ."), { status: 400 });
  const ticketNo = String(input.soPhieu || "").trim().toUpperCase();
  if (!ticketNo || ticketNo.length > 96) throw Object.assign(new Error("Phiếu thiếu số phiếu hoặc số phiếu quá dài."), { status: 400 });
  if (!Array.isArray(input.products) || input.products.length > 300) throw Object.assign(new Error("Danh sách sản phẩm không hợp lệ."), { status: 400 });
  const ticket = { ...input, soPhieu: ticketNo, id, ownerUsername: owner, createdAt: input.createdAt || new Date().toISOString() };
  return { ticket, deliveryMonth: ticketMonth(ticket.ngayGiao || ticket.createdAt), hash: sha256(stableJson(ticket)) };
}
async function addTicketNumberGrams(conn, owner, id, ticketNo) {
  for (const gram of ticketNumberGrams(ticketNo)) {
    await conn.execute("INSERT OR IGNORE INTO ticket_number_grams(owner_username,ticket_id,gram) VALUES(?,?,?)", [owner, id, gram]);
  }
}
async function insertTicket(conn, ticket, owner, actor) {
  const normalized = normalizeTicket(ticket, owner);
  const [existing] = await conn.execute("SELECT payload,payload_hash FROM ticket_history WHERE owner_username=? AND ticket_id=?", [owner, normalized.ticket.id]);
  if (existing.length) {
    if (existing[0].payload_hash === normalized.hash) return { ticket: parseJson(existing[0].payload, normalized.ticket), created: false };
    throw Object.assign(new Error("Mã phiếu đã tồn tại với nội dung khác."), { status: 409 });
  }
  const [numberCollision] = await conn.execute("SELECT owner_username,ticket_id FROM ticket_history WHERE ticket_no=? COLLATE NOCASE LIMIT 1", [normalized.ticket.soPhieu]);
  if (numberCollision.length) throw Object.assign(new Error(`Số phiếu ${normalized.ticket.soPhieu} đã được cấp; hãy lấy số tiếp theo.`), { status: 409 });
  const now = nowSql();
  await conn.execute("INSERT INTO ticket_history (owner_username,ticket_id,ticket_no,delivery_month,payload,payload_hash,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)", [owner, normalized.ticket.id, normalized.ticket.soPhieu, normalized.deliveryMonth || null, JSON.stringify(normalized.ticket), normalized.hash, new Date(normalized.ticket.createdAt), now]);
  await addTicketNumberGrams(conn, owner, normalized.ticket.id, normalized.ticket.soPhieu);
  await saveTicketSearchIndex(conn, normalized.ticket, owner);
  await addAudit(conn, actor, "ticket_created", "ticket", `${owner}:${normalized.ticket.id}`, null, normalized.ticket);
  return { ticket: normalized.ticket, created: true };
}
function historyCursorDecode(value) {
  if (!value) return null;
  try {
    const parsed = JSON.parse(Buffer.from(String(value), "base64url").toString("utf8"));
    if (typeof parsed.createdAt !== "string" || typeof parsed.owner !== "string" || typeof parsed.id !== "string") return null;
    return parsed;
  } catch { return null; }
}
function historyCursorEncode(row) {
  return Buffer.from(JSON.stringify({ createdAt: row.created_at, owner: row.owner_username, id: row.ticket_id })).toString("base64url");
}
function historyWhere(query, month) {
  const where = ["th.deleted_at IS NULL"];
  const params = [];
  if (month) { where.push("th.delivery_month=?"); params.push(month); }
  if (query) {
    const normalized = normalizeSearchText(query);
    if (normalized) {
      where.push("EXISTS (SELECT 1 FROM ticket_search_index si WHERE si.owner_username=th.owner_username AND si.ticket_id=th.ticket_id AND instr(si.search_text,?)>0)");
      params.push(normalized);
    }
  }
  return { where, params };
}
app.post("/api/history/next-number", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const date = String(req.body?.date || "").slice(0, 10);
  const month = ticketMonth(date);
  if (!month) return res.status(400).json({ error: "Ngày giao không hợp lệ để cấp số phiếu." });
  const period = `${month.slice(2, 4)}${month.slice(5, 7)}`;
  const prefix = `PGH-${period}-`;
  const ticketNo = await transaction(async conn => {
    await conn.execute("INSERT OR IGNORE INTO ticket_month_sequences(period,last_seq,updated_at) VALUES(?,0,?)", [period, nowSql()]);
    const [[stored]] = await conn.execute("SELECT last_seq FROM ticket_month_sequences WHERE period=?", [period]);
    const [[observed]] = await conn.execute("SELECT COALESCE(MAX(CAST(substr(ticket_no,?) AS INTEGER)),0) AS max_seq FROM ticket_history WHERE ticket_no LIKE ?", [prefix.length + 1, `${prefix}%`]);
    const next = Math.max(Number(stored?.last_seq || 0), Number(observed?.max_seq || 0)) + 1;
    await conn.execute("UPDATE ticket_month_sequences SET last_seq=?,updated_at=? WHERE period=?", [next, nowSql(), period]);
    return `${prefix}${String(next).padStart(4, "0")}`;
  });
  res.status(201).json({ ticketNo, period });
}));
app.get("/api/history", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const rawLimit = Number(req.query.limit || 60);
  const limit = Math.max(1, Math.min(100, Number.isFinite(rawLimit) ? rawLimit : 60));
  const query = String(req.query.q || "").trim().slice(0, 64);
  const rawMonth = String(req.query.month || "");
  const month = /^\d{4}-\d{2}$/.test(rawMonth) && Number(rawMonth.slice(5)) >= 1 && Number(rawMonth.slice(5)) <= 12 ? rawMonth : "";
  const cursorValue = String(req.query.cursor || "");
  const cursor = historyCursorDecode(cursorValue);
  if (cursorValue && !cursor) return res.status(400).json({ error: "Con trỏ lịch sử không hợp lệ; hãy tải lại danh sách." });
  const filter = historyWhere(query, month);
  const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM ticket_history th WHERE ${filter.where.join(" AND ")}`, filter.params);
  const pageWhere = [...filter.where];
  const pageParams = [...filter.params];
  if (cursor) {
    pageWhere.push("(th.created_at < ? OR (th.created_at = ? AND th.owner_username > ?) OR (th.created_at = ? AND th.owner_username = ? AND th.ticket_id > ?))");
    pageParams.push(cursor.createdAt, cursor.createdAt, cursor.owner, cursor.createdAt, cursor.owner, cursor.id);
  }
  const [rows] = await pool.execute(`SELECT th.owner_username,th.ticket_id,th.ticket_no,th.payload,th.created_at FROM ticket_history th WHERE ${pageWhere.join(" AND ")} ORDER BY th.created_at DESC,th.owner_username ASC,th.ticket_id ASC LIMIT ?`, [...pageParams, limit + 1]);
  const hasMore = rows.length > limit;
  const page = rows.slice(0, limit);
  const [monthRows] = await pool.query("SELECT delivery_month AS month,COUNT(*) AS total FROM ticket_history WHERE deleted_at IS NULL AND delivery_month IS NOT NULL GROUP BY delivery_month ORDER BY delivery_month DESC LIMIT 240");
  const tickets = page.map(row => ({ ...parseJson(row.payload, {}), id: row.ticket_id, ownerUsername: row.owner_username }));
  res.json({ tickets, total: Number(countRows[0]?.total || 0), hasMore, nextCursor: hasMore && page.length ? historyCursorEncode(page[page.length - 1]) : null, months: monthRows.map(row => row.month) });
}));
app.get("/api/history/all", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const [rows] = await pool.query("SELECT owner_username,ticket_id,payload FROM ticket_history WHERE deleted_at IS NULL ORDER BY created_at DESC");
  res.json({ tickets: rows.map(row => ({ ...parseJson(row.payload, {}), id: row.ticket_id, ownerUsername: row.owner_username })) });
}));
app.post("/api/history", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  let result;
  try { result = await transaction(conn => insertTicket(conn, req.body?.ticket, req.pghUser.username, req.pghUser.username)); }
  catch (error) { if (error.status) return res.status(error.status).json({ error: error.message }); throw error; }
  res.status(result.created ? 201 : 200).json({ ticket: result.ticket, duplicate: !result.created });
}));
app.put("/api/history/:ownerUsername/:ticketId", asyncRoute(async (req, res) => {
  if (!needUser(req, res)) return;
  const owner = cleanUsername(req.params.ownerUsername);
  if (!owner || (req.pghUser.role !== "admin" && req.pghUser.username !== owner)) return res.status(403).json({ error: "Không có quyền sửa phiếu này." });
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT payload FROM ticket_history WHERE owner_username=? AND ticket_id=? AND deleted_at IS NULL FOR UPDATE", [owner, req.params.ticketId]);
    if (!rows.length) return null;
    const before = parseJson(rows[0].payload, {});
    const normalized = normalizeTicket({ ...req.body?.ticket, id: req.params.ticketId, createdAt: before.createdAt || req.body?.ticket?.createdAt, updatedAt: new Date().toISOString() }, owner);
    const [numberCollision] = await conn.execute("SELECT owner_username,ticket_id FROM ticket_history WHERE ticket_no=? COLLATE NOCASE AND NOT(owner_username=? AND ticket_id=?) LIMIT 1", [normalized.ticket.soPhieu, owner, req.params.ticketId]);
    if (numberCollision.length) throw Object.assign(new Error(`Số phiếu ${normalized.ticket.soPhieu} đã được cấp.`), { status: 409 });
    await conn.execute("UPDATE ticket_history SET ticket_no=?,delivery_month=?,payload=?,payload_hash=?,updated_at=? WHERE owner_username=? AND ticket_id=?", [normalized.ticket.soPhieu, normalized.deliveryMonth || null, JSON.stringify(normalized.ticket), normalized.hash, nowSql(), owner, req.params.ticketId]);
    await conn.execute("DELETE FROM ticket_number_grams WHERE owner_username=? AND ticket_id=?", [owner, req.params.ticketId]);
    await addTicketNumberGrams(conn, owner, req.params.ticketId, normalized.ticket.soPhieu);
    await saveTicketSearchIndex(conn, normalized.ticket, owner);
    await addAudit(conn, req.pghUser.username, "ticket_updated", "ticket", `${owner}:${req.params.ticketId}`, before, normalized.ticket);
    return normalized.ticket;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy phiếu." });
  res.json({ ticket: result });
}));
app.delete("/api/history/month/:month", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const month = String(req.params.month || "");
  if (!/^\d{4}-\d{2}$/.test(month) || Number(month.slice(5)) < 1 || Number(month.slice(5)) > 12) return res.status(400).json({ error: "Tháng cần xóa không hợp lệ." });
  const result = await transaction(async conn => {
    const [[row]] = await conn.execute("SELECT COUNT(*) AS total FROM ticket_history WHERE delivery_month=? AND deleted_at IS NULL", [month]);
    const count = Number(row?.total || 0);
    if (!count) return { count: 0 };
    await conn.execute("UPDATE ticket_history SET deleted_at=?,deleted_by=? WHERE delivery_month=? AND deleted_at IS NULL", [nowSql(), req.pghUser.username, month]);
    await addAudit(conn, req.pghUser.username, "tickets_bulk_deleted", "ticket_collection", month, { count, month }, { count: 0, deletedBy: req.pghUser.username });
    return { count };
  });
  res.json({ success: true, deleted: result.count });
}));
app.delete("/api/history/:ownerUsername/:ticketId", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const owner = cleanUsername(req.params.ownerUsername);
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT payload FROM ticket_history WHERE owner_username=? AND ticket_id=? AND deleted_at IS NULL FOR UPDATE", [owner, req.params.ticketId]);
    if (!rows.length) return null;
    const before = parseJson(rows[0].payload, {});
    await conn.execute("UPDATE ticket_history SET deleted_at=?,deleted_by=? WHERE owner_username=? AND ticket_id=?", [nowSql(), req.pghUser.username, owner, req.params.ticketId]);
    await addAudit(conn, req.pghUser.username, "ticket_deleted", "ticket", `${owner}:${req.params.ticketId}`, before, null);
    return true;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy phiếu." });
  res.json({ success: true });
}));
app.delete("/api/history", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const owner = req.pghUser.username;
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT ticket_id,ticket_no,payload FROM ticket_history WHERE owner_username=? AND deleted_at IS NULL FOR UPDATE", [owner]);
    if (!rows.length) return { count: 0 };
    await conn.execute("UPDATE ticket_history SET deleted_at=?,deleted_by=? WHERE owner_username=? AND deleted_at IS NULL", [nowSql(), owner, owner]);
    await addAudit(conn, owner, "tickets_bulk_deleted", "ticket_collection", owner, { count: rows.length, tickets: rows.map(row => ({ id: row.ticket_id, soPhieu: row.ticket_no })) }, null);
    return { count: rows.length };
  });
  res.json({ success: true, deleted: result.count });
}));
app.delete("/api/history/all", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const result = await transaction(async conn => {
    const [[row]] = await conn.execute("SELECT COUNT(*) AS total FROM ticket_history WHERE deleted_at IS NULL");
    const count = Number(row?.total || 0);
    if (!count) return { count: 0 };
    await conn.execute("UPDATE ticket_history SET deleted_at=?,deleted_by=? WHERE deleted_at IS NULL", [nowSql(), req.pghUser.username]);
    await addAudit(conn, req.pghUser.username, "tickets_bulk_deleted", "ticket_collection", "all", { count, month: "all" }, { count: 0, deletedBy: req.pghUser.username });
    return { count };
  });
  res.json({ success: true, deleted: result.count });
}));

app.post("/api/history/import-local", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const items = Array.isArray(req.body?.tickets) ? req.body.tickets.slice(0, 300) : [];
  let imported = 0, rejected = 0;
  for (const item of items) {
    try {
      const result = await transaction(conn => insertTicket(conn, item, req.pghUser.username, req.pghUser.username));
      if (result.created) imported++;
    } catch (error) { if (error.status === 400 || error.status === 409) rejected++; else throw error; }
  }
  res.json({ imported, rejected });
}));

app.get("/api/users", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const [rows] = await pool.query("SELECT username,email,role,active,created_at,last_signed_in FROM app_users ORDER BY username");
  res.json({ users: rows.map(publicUser) });
}));
app.post("/api/users", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const username = cleanUsername(req.body?.username);
  const password = req.body?.password;
  const role = req.body?.role === "admin" ? "admin" : req.body?.role === "staff" ? "staff" : "";
  const email = String(req.body?.email || "").trim().slice(0, 254) || null;
  if (!username || !role) return res.status(400).json({ error: "Tên tài khoản hoặc vai trò không hợp lệ." });
  if (!validatePassword(password)) return res.status(400).json({ error: "Mật khẩu cần từ 12 đến 256 ký tự." });
  const passwordHash = await hashPassword(password);
  const account = { username, email: email || "", role, active: true };
  try {
    await transaction(async conn => {
      await conn.execute("INSERT INTO app_users (username,password_hash,email,role,active,created_at,updated_at) VALUES (?,?,?,?,1,?,?)", [username, passwordHash, email, role, nowSql(), nowSql()]);
      await addAudit(conn, req.pghUser.username, "account_created", "account", username, null, account);
    });
  } catch (error) { if (isDuplicateError(error)) return res.status(409).json({ error: "Tên tài khoản đã tồn tại." }); throw error; }
  res.status(201).json({ user: account });
}));
app.patch("/api/users/:username/status", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const username = cleanUsername(req.params.username);
  const active = req.body?.active;
  if (!username || typeof active !== "boolean") return res.status(400).json({ error: "Trạng thái tài khoản không hợp lệ." });
  if (!active && username === req.pghUser.username) return res.status(400).json({ error: "Không thể tự khóa tài khoản đang đăng nhập." });
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT username,email,role,active FROM app_users WHERE username=? FOR UPDATE", [username]);
    if (!rows.length) return null;
    const before = { ...rows[0], active: Boolean(rows[0].active) };
    if (!active && before.role === "admin" && before.active) {
      const [[countRow]] = await conn.query("SELECT COUNT(*) AS total FROM app_users WHERE role='admin' AND active=1");
      if (Number(countRow.total) <= 1) throw Object.assign(new Error("Không thể khóa Admin cuối cùng."), { status: 400 });
    }
    await conn.execute("UPDATE app_users SET active=?,updated_at=? WHERE username=?", [active ? 1 : 0, nowSql(), username]);
    if (!active) await conn.execute("DELETE FROM app_sessions WHERE username=?", [username]);
    const after = { ...before, active };
    await addAudit(conn, req.pghUser.username, active ? "account_activated" : "account_deactivated", "account", username, before, after);
    return after;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy tài khoản." });
  res.json({ user: result });
}));
app.put("/api/users/:username/password", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const username = cleanUsername(req.params.username);
  if (!username) return res.status(400).json({ error: "Tên tài khoản không hợp lệ." });
  if (!validatePassword(req.body?.password)) return res.status(400).json({ error: "Mật khẩu cần từ 12 đến 256 ký tự." });
  const passwordHash = await hashPassword(req.body.password);
  const result = await transaction(async conn => {
    const [rows] = await conn.execute("SELECT username,email,role,active FROM app_users WHERE username=? FOR UPDATE", [username]);
    if (!rows.length) return false;
    const before = { ...rows[0], active: Boolean(rows[0].active), passwordChanged: false };
    await conn.execute("UPDATE app_users SET password_hash=?,updated_at=? WHERE username=?", [passwordHash, nowSql(), username]);
    if (username === req.pghUser.username && req.sessionHash) {
      await conn.execute("DELETE FROM app_sessions WHERE username=? AND session_hash<>?", [username, req.sessionHash]);
    } else {
      await conn.execute("DELETE FROM app_sessions WHERE username=?", [username]);
    }
    await addAudit(conn, req.pghUser.username, "account_password_reset", "account", username, before, { ...before, passwordChanged: true });
    return true;
  });
  if (!result) return res.status(404).json({ error: "Không tìm thấy tài khoản." });
  res.json({ success: true });
}));
app.post("/api/users/migrate-local", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const users = Array.isArray(req.body?.users) ? req.body.users.slice(0, 200) : [];
  let imported = 0, rejected = 0;
  for (const item of users) {
    const username = cleanUsername(item?.username);
    if (!username || username === "admin") { rejected++; continue; }
    const randomHash = await hashPassword(randomBytes(32).toString("hex"));
    const account = { username, email: String(item.email || "").slice(0, 254), role: item.role === "admin" ? "admin" : "staff", active: false, requiresPasswordReset: true };
    try {
      await transaction(async conn => {
        await conn.execute("INSERT INTO app_users (username,password_hash,email,role,active,created_at,updated_at) VALUES (?,?,?,?,0,?,?)", [username, randomHash, account.email || null, account.role, nowSql(), nowSql()]);
        await addAudit(conn, req.pghUser.username, "account_migrated", "account", username, null, account);
      });
      imported++;
    } catch (error) { if (isDuplicateError(error)) continue; throw error; }
  }
  res.json({ imported, rejected });
}));

app.get("/api/audit", asyncRoute(async (req, res) => {
  if (!needAdmin(req, res)) return;
  const requestedLimit = Number(req.query.limit || 100);
  const limit = Math.max(1, Math.min(100, Number.isFinite(requestedLimit) ? requestedLimit : 100));
  const beforeId = /^\d+$/.test(String(req.query.beforeId || "")) ? String(req.query.beforeId) : "";
  const [rows] = beforeId
    ? await pool.execute("SELECT id,actor_username,action,entity_type,entity_key,before_json,after_json,created_at FROM audit_events WHERE id<? ORDER BY id DESC LIMIT ?", [beforeId, limit + 1])
    : await pool.execute("SELECT id,actor_username,action,entity_type,entity_key,before_json,after_json,created_at FROM audit_events ORDER BY id DESC LIMIT ?", [limit + 1]);
  const hasMore = rows.length > limit;
  const page = rows.slice(0, limit);
  const events = page.map(row => ({
    id: String(row.id), actorUsername: row.actor_username, action: row.action,
    entityType: row.entity_type, entityKey: row.entity_key,
    before: parseJson(row.before_json), after: parseJson(row.after_json),
    createdAt: new Date(row.created_at).toISOString(),
  }));
  res.json({ events, hasMore, nextBeforeId: hasMore && events.length ? events[events.length - 1].id : null });
}));

app.use((req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Không tìm thấy API." });
  res.status(404).send("Không tìm thấy trang.");
});
app.use((error, _req, res, _next) => {
  console.error("[server]", error?.message || error);
  if (res.headersSent) return;
  const status = Number(error?.status) || 500;
  res.status(status).json({ error: status < 500 ? error.message : "Máy chủ gặp lỗi. Vui lòng thử lại." });
});

const port = Number(process.env.PORT || 43128);
const host = process.env.HOST || "127.0.0.1";
await applyMigration();
if (localNoAuth) await ensureLocalAdmin();
await pool.query("SELECT 1");
export const httpServer = await new Promise((resolve, reject) => {
  const server = app.listen(port, host);
  server.once("listening", () => resolve(server));
  server.once("error", reject);
});
console.log(`Embedded local API listening on ${host}:${port}; database: ${databasePath}`);
export async function shutdownEmbeddedServer() {
  if (httpServer.listening) await new Promise((resolve, reject) => httpServer.close(error => error ? reject(error) : resolve()));
  database.close();
}
