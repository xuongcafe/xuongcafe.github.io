PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_users (
  username TEXT NOT NULL PRIMARY KEY,
  password_hash TEXT NOT NULL,
  email TEXT,
  role TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('admin','staff')),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_signed_in TEXT
);

CREATE TABLE IF NOT EXISTS app_sessions (
  session_hash TEXT NOT NULL PRIMARY KEY,
  username TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  FOREIGN KEY (username) REFERENCES app_users(username) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON app_sessions(username);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON app_sessions(expires_at);

CREATE TABLE IF NOT EXISTS ticket_history (
  owner_username TEXT NOT NULL,
  ticket_id TEXT NOT NULL,
  ticket_no TEXT NOT NULL,
  delivery_month TEXT,
  payload TEXT NOT NULL CHECK (json_valid(payload)),
  payload_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  deleted_by TEXT,
  PRIMARY KEY (owner_username, ticket_id)
);
CREATE INDEX IF NOT EXISTS idx_ticket_feed ON ticket_history(deleted_at, created_at DESC, owner_username, ticket_id);
CREATE INDEX IF NOT EXISTS idx_ticket_owner_active ON ticket_history(owner_username, deleted_at, created_at DESC, ticket_id);
CREATE INDEX IF NOT EXISTS idx_ticket_delivery_month ON ticket_history(deleted_at, delivery_month, created_at DESC, owner_username, ticket_id);
CREATE INDEX IF NOT EXISTS idx_ticket_no ON ticket_history(ticket_no COLLATE NOCASE);

CREATE TABLE IF NOT EXISTS ticket_month_sequences (
  period TEXT NOT NULL PRIMARY KEY,
  last_seq INTEGER NOT NULL DEFAULT 0 CHECK (last_seq >= 0),
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ticket_number_grams (
  owner_username TEXT NOT NULL,
  ticket_id TEXT NOT NULL,
  gram TEXT NOT NULL,
  PRIMARY KEY (owner_username, ticket_id, gram),
  FOREIGN KEY (owner_username, ticket_id) REFERENCES ticket_history(owner_username, ticket_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ticket_number_gram ON ticket_number_grams(gram, owner_username, ticket_id);

CREATE TABLE IF NOT EXISTS pgh_desktop_migrations (
  version INTEGER NOT NULL PRIMARY KEY,
  applied_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS catalog_customers (
  customer_code TEXT NOT NULL PRIMARY KEY,
  payload TEXT NOT NULL CHECK (json_valid(payload)),
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  deleted_by TEXT
);

CREATE TABLE IF NOT EXISTS catalog_products (
  product_code TEXT NOT NULL PRIMARY KEY,
  payload TEXT NOT NULL CHECK (json_valid(payload)),
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  deleted_by TEXT
);

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key TEXT NOT NULL PRIMARY KEY,
  settings_json TEXT NOT NULL CHECK (json_valid(settings_json)),
  updated_by TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_username TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  before_json TEXT CHECK (before_json IS NULL OR json_valid(before_json)),
  after_json TEXT CHECK (after_json IS NULL OR json_valid(after_json)),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at, id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_events(actor_username, id);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_key, id);
