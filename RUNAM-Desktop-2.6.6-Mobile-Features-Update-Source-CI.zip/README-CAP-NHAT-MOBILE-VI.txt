RUNAM DESKTOP 2.6.6 – CẬP NHẬT TÍNH NĂNG MOBILE
=================================================

Mục tiêu
--------
Bản Desktop sử dụng giao diện và các luồng nghiệp vụ từ app.js Mobile hiện tại,
nhưng dữ liệu vẫn được xử lý bởi API cục bộ và SQLite của Desktop.

Các phần đã đồng bộ
-------------------
- Giao diện tạo, sửa, xem trước và in phiếu theo app.js Mobile.
- Lịch sử phiếu, bộ lọc tháng/ngày và tìm kiếm theo số phiếu, số phiếu xuất,
  PO, khách hàng, địa chỉ, người nhận, điện thoại và sản phẩm.
- Tìm kiếm không phân biệt dấu tiếng Việt; có thể gõ từ 1 ký tự.
- Kết quả tìm kiếm được truy vấn từ toàn bộ dữ liệu SQLite, không chỉ trang
  lịch sử đang hiển thị; danh sách gợi ý xổ xuống giữ cách hoạt động Mobile.
- Các cài đặt nhãn, giao diện, cỡ chữ, ẩn/hiện nội dung in, logo và thông tin
  công ty được lưu qua /api/settings trong SQLite.
- Backup JSON phiên bản 5 có thêm titleSizes để mang đầy đủ cài đặt cỡ chữ.
- Nhập backup vẫn theo hướng bổ sung: phiếu đã tồn tại hoặc trùng số phiếu
  được bỏ qua; không xóa dữ liệu đang có.
- Giữ Electron, API nội bộ, SQLite và chuyển backup qua Wi-Fi LAN.

Thay đổi kỹ thuật
-----------------
- Tạo bảng ticket_search_index và migration version 3. Khi mở ứng dụng lần
  đầu sau cập nhật, dữ liệu lịch sử hiện có được lập chỉ mục theo từng lô
  500 phiếu; không xóa hoặc sửa nội dung phiếu.
- Phiếu mới và phiếu được sửa sẽ tự cập nhật chỉ mục tìm kiếm.
- Mở rộng schema cài đặt để giữ boxBg và các tùy chọn chữ ký của Mobile.

Cập nhật máy đang sử dụng
-------------------------
1. Sao lưu JSON từ Desktop và Mobile trước khi cập nhật.
2. Đóng ứng dụng RUNAM Desktop.
3. Trên máy Windows, chạy BUILD-WIN.bat trong thư mục nguồn để tạo bộ cài.
4. Chạy bộ cài mới lên phiên bản đang dùng. Không xóa thư mục dữ liệu ứng dụng.
5. Mở RUNAM, kiểm tra cài đặt, lịch sử, tìm kiếm và thử xuất/nhập backup.

Lưu ý
-----
- Bộ mã nguồn này chưa phải file Setup.exe đã build và chưa được chạy thử trên
  máy Windows 7/10 thật trong môi trường hiện tại.
- Native module better-sqlite3 phải được rebuild trên Windows cho Electron
  bằng quy trình BUILD-WIN.bat.
- Luôn giữ một bản backup JSON độc lập trước khi cập nhật.

CAP NHAT BO MAU IN 2.6.6
- Gach duoi tieu de PHIEU GIAO HANG tiep tuc dung Mau chinh.
- Them mau nen rieng cho o THONG TIN PHIEU (boxBgInfo).
- Them mau nen rieng cho o THONG TIN KHACH HANG (boxBgCustomer).
- Hai mau duoc luu trong theme/settings va di theo backup JSON.
- Mau boxBg cu duoc giu lam tuong thich nguoc neu du lieu cai dat cu con su dung.

BUILD QUA GITHUB ACTIONS
- Workflow: .github/workflows/build-runam-desktop.yml
- Dua file RUNAM-Desktop-2.6.6-Mobile-Features-Update-Source.zip vao thu muc goc repository xuongcafe/xuongcafe.github.io.
- Khi ZIP duoc push len repository, GitHub Actions tu dong build tren Windows runner.
- Tai file RUNAM-Setup-2.6.6-Win7-Win10-x64.exe trong muc Actions > workflow run > Artifacts.
- Neu can chay lai, vao Actions > Build RUNAM Desktop Setup > Run workflow.
