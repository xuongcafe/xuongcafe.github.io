RUNAM DESKTOP 2.6.5 — FEATURES 1–8, SOURCE V26

Nội dung source
- public/: giao diện RUNAM và tài nguyên tĩnh.
- desktop/main.cjs và desktop/preload.cjs: Electron main process và cầu nối an toàn.
- server/server.mjs và server/migrations/: API chạy cục bộ và schema SQLite.
- node_modules/: dependencies ứng dụng đã dùng trong bản v26.
- package.json: tên/version và dependencies của ứng dụng.

Không có database, backup JSON, dữ liệu khách hàng/sản phẩm/phiếu, hay thông tin đăng nhập trong gói này. Dữ liệu được tạo cục bộ khi ứng dụng chạy trên máy người dùng. Source không chứa bản cài Electron độc lập; file Setup.exe là artifact riêng. Để sử dụng ngay trên Windows, dùng bộ cài v26 được cung cấp tách biệt. Tự đóng gói lại cần Electron runtime phù hợp, NSIS và cấu hình Windows x64 tương ứng; không chạy lệnh npm start vì source này vốn được đóng trong ứng dụng Electron.
